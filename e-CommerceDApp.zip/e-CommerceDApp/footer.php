<?php
            echo
            '<footer class="bg-primary text-center text-lg-start" style="margin-top: 0px">

                <div class="container p-4">

                    <div class="row">

                        <div class="col-lg-6 col-md-12 mb-4 mb-md-0">

                            <h5 class="text-uppercase"> Libri scontati e in offerta! </h5>

                            <p>
                                Su Lorvincfralma trovi tutte le novità editoriali in commercio, tantissimi nuovi libri da leggere, libri di prossima uscita che puoi facilmente prenotare. Un intero catalogo di libri a tua disposizione. Migliaia di libri in offerta di qualsiasi genere!
                            </p>

                        </div>

                        <div style="margin-left: 20px;">

                            <h2 class="text-uppercase"> Contatti </h2>

                            <ul class="list-unstyled mb-0">

                                <li class="footerLi">

                                    <i class="bi bi-geo-alt">

                                        <a name="contatti" href="https://goo.gl/maps/RF6fg7231HP7jtCt9" target="_blank" class="text-dark"> 
                                            Via delle Belle Arti, 40126 Bologna BO 
                                        </a>

                                    </i>

                                </li>

                                <li class="footerLi">

                                    <i class="bi bi-telephone">
                                    
                                        <a href="tel:051 262303" class="text-dark"> 051 262303 </a>

                                    </i>

                                </li>

                                <li class="footerLi">

                                    <i class="bi bi-envelope">
                                        
                                        <a href="mailto:lorvincfralma@gmail.com" class="text-dark">
                                            lorvincfralma@gmail.com
                                        </a>

                                    </i>

                                </li>

                            </ul>

                        </div>

                    </div>

                </div>

                <!-- Copyright -->
                <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
                    © Vincenzo Fraello (299647) - Lorenzo Di Palma (299636)
                </div>

                <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
            </script>

            </footer>

        </body>

    </html>';

    // <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    //         integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    //     </script>

    //     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
    //         integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
    //     </script>